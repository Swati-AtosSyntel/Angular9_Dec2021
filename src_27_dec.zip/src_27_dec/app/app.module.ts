import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {Routes,RouterModule} from '@angular/router';
import { AppComponent } from './app.component';
import { EmployeelistComponent } from './employeelist/employeelist.component';
import { BasicComponent } from './basic/basic.component';
import { GenderPipe } from './gender.pipe';
import { CustomtitlePipe } from './customtitle.pipe';
import {UsersListComponent} from './users-list/users-list.component'
import { EmployeecountComponent } from './employeecount/employeecount.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
const routes:Routes=[
{path:'home',component:BasicComponent},
{path:'employeelist',component:EmployeelistComponent},
{path:'userlist',component:UsersListComponent},
{path:'',redirectTo:'home',pathMatch:'full'},
{path:'**',component:PagenotfoundComponent}

];
@NgModule({
  declarations: [
    AppComponent,
    EmployeelistComponent,
    BasicComponent,
    GenderPipe,
    CustomtitlePipe,
    UsersListComponent,
    EmployeecountComponent,
    PagenotfoundComponent
  ],
  imports: [
    BrowserModule,FormsModule,HttpClientModule,RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
