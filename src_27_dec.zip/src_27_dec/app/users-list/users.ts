export class Users{
    id:number=0;
    username:string="";
    email:string="";

}