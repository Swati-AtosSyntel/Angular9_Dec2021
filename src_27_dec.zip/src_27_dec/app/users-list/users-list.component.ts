import { Component, OnInit } from '@angular/core';


import { HttpClient } from '@angular/common/http';
import { Users } from './users';

@Component({
  selector: 'app-users-list',
  templateUrl: './users-list.component.html',
  styleUrls: ['./users-list.component.css']
})
export class UsersListComponent implements OnInit {

  userdetails:Users[]=[];

  constructor(private http:HttpClient){

  }

  ngOnInit(): void {
   this.getUsers();
  }
  getUsers(){
    this.http.get<Users[]>("https://jsonplaceholder.typicode.com/users")
     .subscribe((data)=>{
       this.userdetails=data;
       console.log(this.userdetails);
     },
     (error)=>{
       console.error("Request failed");
     },
     ()=>{
       console.log("Request completed");
     })
}
}
