import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'customtitle'
})
export class CustomtitlePipe implements PipeTransform {

  transform(value: any,): any {
    console.log("In gender pipe transform method!!!");
    var genderval=1;
    
  switch(genderval){
    case 1:return "Mr.";
    case 2:return "Miss";
  }
  }

}
