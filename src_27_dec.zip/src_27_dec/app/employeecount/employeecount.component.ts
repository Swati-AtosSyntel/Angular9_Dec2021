import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-employeecount',
  templateUrl: './employeecount.component.html',
  styleUrls: ['./employeecount.component.css']
})
export class EmployeecountComponent implements OnInit {
@Input()
All:number=0;
@Input()
Male:number=0;
@Input()
Female:number=0;

selectedRadioButtonValue:string="All";
  constructor() { }

  ngOnInit(): void {
  }
@Output()
countRadioButtonSelectionChanged:EventEmitter<string>=new EventEmitter<string>();

onRadioButtonSelectionChange(){
  this.countRadioButtonSelectionChanged.emit(this.selectedRadioButtonValue);
  console.log(this.selectedRadioButtonValue);
}

}
