import { Directive, ElementRef, HostListener,Renderer2,HostBinding } from '@angular/core';

@Directive({
  selector: '[appTtTogle]'
})
export class TtTogleDirective {

  elementSelected=false;

  constructor(private el:ElementRef) { }
  @HostListener('click')
private onClick(){
  this.elementSelected=!this.elementSelected;
  if(this.elementSelected){
    this.el.nativeElement.classList.Add('toggle');

  }
  else{
    this.el.nativeElement.classList.remove('toggle')
  }

}
}
