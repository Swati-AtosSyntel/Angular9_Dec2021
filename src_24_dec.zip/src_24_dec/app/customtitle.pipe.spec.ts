import { CustomtitlePipe } from './customtitle.pipe';

describe('CustomtitlePipe', () => {
  it('create an instance', () => {
    const pipe = new CustomtitlePipe();
    expect(pipe).toBeTruthy();
  });
});
