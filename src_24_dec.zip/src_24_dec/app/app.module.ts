import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { EmployeelistComponent } from './employeelist/employeelist.component';
import { BasicComponent } from './basic/basic.component';
import { GenderPipe } from './gender.pipe';
import { CustomtitlePipe } from './customtitle.pipe';
import { TtTogleDirective } from './tt-togle.directive';

@NgModule({
  declarations: [
    AppComponent,
    EmployeelistComponent,
    BasicComponent,
    GenderPipe,
    CustomtitlePipe,
    TtTogleDirective
  ],
  imports: [
    BrowserModule,FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
