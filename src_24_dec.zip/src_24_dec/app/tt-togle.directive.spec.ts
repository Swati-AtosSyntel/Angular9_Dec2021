import { TtTogleDirective } from './tt-togle.directive';

describe('TtTogleDirective', () => {
  it('should create an instance', () => {
    const directive = new TtTogleDirective();
    expect(directive).toBeTruthy();
  });
});
