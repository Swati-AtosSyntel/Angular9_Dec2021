import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic',
  templateUrl: './basic.component.html',
  styleUrls: ['./basic.component.css']
})
export class BasicComponent implements OnInit {
title="AngularApplication 1";
colors=['Red','Blue','Green','Orange'];
day=1;
name={fname:'Nilesh',lname:'Patil'};
  constructor() { }

  ngOnInit(): void {
  }
  flag=true;
  updateTitle(){
    this.title="First Angular Application!!!!";
  }
}
